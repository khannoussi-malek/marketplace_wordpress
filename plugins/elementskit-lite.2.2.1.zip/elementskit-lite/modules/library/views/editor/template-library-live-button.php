<# if ( '' != livelink ) { #>
	<a class="elementor-template-library-template-action elementskit-preview-button-live"  href="{{livelink}}" target="_blank">
		<i class="eicon-editor-external-link"></i>
		<span class="elementor-button-title"><?php
			esc_html_e( 'Live Preview', 'elementskit-lite' );
		?></span>
	</a>
<# } #>