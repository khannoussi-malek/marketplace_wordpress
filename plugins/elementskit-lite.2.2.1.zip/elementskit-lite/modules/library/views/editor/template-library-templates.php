<?php
/**
 * Templates list view
 */
?>
<div id="elementskit-template-library-templates-container"></div>