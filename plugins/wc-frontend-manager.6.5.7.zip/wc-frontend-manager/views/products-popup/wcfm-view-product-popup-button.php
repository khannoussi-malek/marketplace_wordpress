<div class="wcfm_product_popup_button_wrapper">
  <div role="button" class="wcfm_product_popup_button text_tip" data-tip="<?php _e( 'Add New Product', 'wc-frontend-manager' ); ?>">
    <div class="wcfm_product_popup_button_inner"></div>
    <div class="wcfm_product_popup_button_inner_hidden"></div>
    <content class="wcfm_product_popup_button_icon"><i class="wcfmfa fa-cube"></i></content>
  </div>
</div>