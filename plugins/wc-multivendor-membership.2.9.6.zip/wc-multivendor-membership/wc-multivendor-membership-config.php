<?php

define('WCFMvm_TOKEN', 'wcfmvm');

define('WCFMvm_TEXT_DOMAIN', 'wc-multivendor-membership');

define('WCFMvm_VERSION', '2.9.6');

define('WCFMvm_SERVER_URL', 'https://wclovers.com');

?>