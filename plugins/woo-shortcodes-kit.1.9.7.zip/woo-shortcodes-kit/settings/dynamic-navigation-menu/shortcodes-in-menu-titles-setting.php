<?php 

/* Shortcodes in menu titles settings*/

?>

<!-- header -->
  <div class="accordion">
  <table>
  <colgroup>
    <col span="2">
   
  </colgroup>
  <tr>
    <th><p><input type="checkbox" class="testininputclass" id="wshk_enableshtmenu" name="wshk_enableshtmenu" value='18' <?php if(get_option('wshk_enableshtmenu')!=''){ echo ' checked="checked"'; }?>/><label class="testintheclass" for=wshk_enableshtmenu></label><br /></th><th class="forcontainertitles" style="padding: 20px 20px 0px 20px;"> <big><?php esc_html_e( 'Shortcodes in menu titles', 'woo-shortcodes-kit' ); ?></big><br /><small> <?php esc_html_e( 'Just need activate the function and nothing more!', 'woo-shortcodes-kit' ); ?></small></p></th></tr>
    </table>
</div>
<!-- content -->
<div class="panel">
    <br><br>
    <table style="float:right;"><tr><td><a class="miraqueben" href="https://disespubli.com/docs/shortcodes-in-menu-titles/" target="_blank" style="color: grey;"><span class="dashicons dashicons-book"></span> <?php esc_html_e( 'How does it work? ', 'woo-shortcodes-kit' ); ?> </a></td><td><a class="miraqueben" href="https://disespubli.com/wshk-features/#contact" class="botoneratopadmin" target="_blank" style="color:grey;"><span class="dashicons dashicons-sos"></span> <?php esc_html_e( 'Get help!', 'woo-shortcodes-kit' ); ?></a></td></tr></table>
    <br /><br />
<p class="wshkfirststepfunc"><b><?php esc_html_e( 'Once the function is activated, you can add a shortcode in each menu item title.', 'woo-shortcodes-kit' ); ?></b></p>
    <p><?php esc_html_e( 'You can combine this function with the others of the same category.', 'woo-shortcodes-kit' ); ?></p>
    <br />
    <br />
    </div>