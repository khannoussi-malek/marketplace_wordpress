<?php
/*
Automcomplete the virtual products orders
*/
?>
<!-- Header -->
     <div class="accordion">
  <table>
  <colgroup>
    <col span="2">
   
  </colgroup>
  
         <th><p><input type="checkbox" class="testininputclass" id="wshk_enableautocom" name="wshk_enableautocom" value='84' <?php if(get_option('wshk_enableautocom')!=''){ echo ' checked="checked"'; }?>/><label class="testintheclass" for=wshk_enableautocom></label><br /></th><th class="forcontainertitles" style="padding: 20px 20px 0px 20px;"><big><?php esc_html_e( 'Autocomplete the virtual products orders', 'woo-shortcodes-kit' ); ?></big><br /><small><?php esc_html_e( 'Just need activate the function and nothing more!', 'woo-shortcodes-kit' ); ?></small></p></th>
         </table>
</div>
<!-- content -->
<div class="panel">
    <br><br>
    <table style="float:right;"><tr><td><a class="miraqueben" href="https://disespubli.com/docs/autocomplete-the-virtual-products-orders/" target="_blank" style="color: grey;"><span class="dashicons dashicons-book"></span> <?php esc_html_e( 'How does it work? ', 'woo-shortcodes-kit' ); ?> </a></td><td><a class="miraqueben" href="https://disespubli.com/wshk-features/#contact" class="botoneratopadmin" target="_blank" style="color:grey;"><span class="dashicons dashicons-sos"></span> <?php esc_html_e( 'Get help!', 'woo-shortcodes-kit' ); ?></a></td></tr></table>
    <br /><br />
    <table>
          <colgroup>
    <col span="3">
   
  </colgroup>
         <tr>
        <td style="width: 100%; padding-left: 30px;"><p class="wshkfirststepfunc"><b><?php esc_html_e( 'With this function your orders will be completed automaticlly, just active it and forget the processing status.', 'woo-shortcodes-kit' ); ?></b><br><small><?php esc_html_e( 'All the orders with virtual products will be changed to the completed status.', 'woo-shortcodes-kit' ); ?></small></p><br><!--<div style="background-color:#a46497;padding:20px;color:white;"><strong><?php esc_html_e( 'This function is not valid for stores that need their orders to go through different states before being completed. For example, if you sell physical products and orders must go through states such as processing, shipping, until you reach the completed order status, this function is not recommended for your store, since it will cause the order to pass from the processing to the complete directly.', 'woo-shortcodes-kit' ); ?></strong></div>--><br /><br /> </td>
        
       </tr>
        
        <br />
        <br />
        </table>
        </div>