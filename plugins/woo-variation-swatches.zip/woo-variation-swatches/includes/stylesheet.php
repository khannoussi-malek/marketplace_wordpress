<?php
	defined( 'ABSPATH' ) or die( 'Keep Silent' );
?>
<style type="text/css">
    .variable-item:not(.radio-variable-item) {
        width  : <?php echo $width ?>px;
        height : <?php echo $height ?>px;
        }

    .wvs-style-squared .button-variable-item {
        min-width : <?php echo $width ?>px;
        }

    .button-variable-item span {
        font-size : <?php echo $font_size ?>px;
        }
</style>
